/*********************************************************************
*	CHENILLARD V2.00 23/11/01 CH_84_V2
*	Commande de LED suivant un cycle determine et commande de BP
*	Claude DRESCHEL 
*	
********************************************************************/

#include	<pic1684.h>

#define INIT_PORTA      TRISA = 0b10000;    //PortA = RA4=In
#define INIT_PORTB      TRISB = 0b00000001  //PortB RB0=In
		

static bit BP          	@ ((unsigned)&PORTB*8+0);	// BP_NORM et BP_INV

//***********************************************************************
static bit bp_on,temps,bp_inv;
unsigned char nb;
const unsigned int cycle_B[10]={2,4,8,16,32,64,128,0,0,0};
const unsigned int cycle_A[10]={0,0,0,0,0,0,0,1,2,4};


//***************************************************************
void init_pic(void);
void interrupt traite_int(void);

//***************************************************************
void main(void)
{
signed char init_pos;
unsigned char n;
	init_pos=0; //position 0 dans les tableaux
	bp_on=0;	
	bp_inv=0;
	init_pic(); //initialisation du PIC
	PORTB=cycle_B[init_pos];  //LED1=ON sur portB
	PORTA=cycle_A[init_pos];	

	do
	{     
		while(!bp_on); 	//attend BP
		INTE=0;		//plus d'interruption sur RB0
		TMR0=0x0;		//compteur=0
		nb=0;			//dur�e nb=0
		n=0;			// 11 cycle (10 LED+1)
		if(RA4==0) bp_inv=1; //BP_INV appuye
		while(!BP);    //lache le BP ?
		temps=0;		
		T0IE=1;        //TMR0 actif :debut tempo anti-rebond BP 
		
		do
		{    
			if(bp_inv==0)       //sens normal
			{
		        	init_pos++;  //commence LED suivante
				if(init_pos > 9) init_pos=0;
			}else			//sens inverse
			{
				init_pos--;
				if(init_pos < 0) init_pos=9;
			}	
			PORTB=cycle_B[init_pos]; //allume LEDs portB
			PORTA=cycle_A[init_pos]; //allume LEDs portA
			while(!temps);		 // attend fin tempo 
			temps=0;
			n++;
					
		}while(n!=11);    //tant que 10+1 LED allumees
                T0IE=0;		//invalide interruption TMR0
                bp_inv=0;
		    bp_on=0;
                INTE=1;		//valide interruption BP sur RB0
		
		
	}while(!0);			//on recommence
}

//**************************************************************
void interrupt traite_int(void)
{
    	      
        if(INTF)		// interruption RB0
        {
	  	bp_on=1;    // signale BP actionne
		INTF=0;     //efface flag INTF  
        }
        if(T0IF)		// interruption TMR0
        {
		if(++nb==4)  // nb determine la duree LED allumee
		{
			temps=1;  // fin tempo
			nb=0;
		}
            
	      T0IF=0;		//efface flag T0IF
	 }        
}
//**************************************************************
void init_pic(void)
{     
      INIT_PORTA;	 //config PORTA
      INIT_PORTB;	 //config PORTB	
      OPTION=0b00000111; //config prediviseur et TMR0
	T0IF=0;	//Flag TIMER0 interrupt
	TMR0=0x0;	//registre TIMER0=0
	T0IE=0;	//ne valide pas les interruptions TMR0
      INTE=1;	// valide interruption BP sur RB0
	GIE=1;	//valide toutes les interruptions 
      	
      
}
//**************************************************************
//		FIN
//**************************************************************
