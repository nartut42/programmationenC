/**********************************************************************/
/*    DCL639
 *    Circuit compatible avec le FT639
 *    Utilise un PIC 12C671 
 *    Auteur: Claude Dreschel
 *    Claude Dreschel <Claudedel@wanadoo.fr>
 **********************************************************************/
#include	<pic1267x.h>


 
#define	XTAL	        4000000	        //  4.000 MHz
#define	PORTBIT(adr, bit)	((unsigned)(&adr)*8+(bit))
#define ON      1
#define OFF     0 
#define DIV_8   0b10000010	// predivise par 8
#define DIV_16  0b10000011	// predivise par 16
#define DIV_256 0b10000111      // par 256
/*	Baud rate	*/

#define	BRATE	2400		//2400 bauds

/*	Parametres  */

#define	DLY		3		// 3 cycles de boucle attente
#define	RX_TEMPO	33		// 33 Fixe le temps de scrutation Rxd 
#define	DELAY(tempo)	(((XTAL/4/BRATE)-(tempo))/DLY)
/*      Commandes compatibles FT639        */

#define SETUPMODE       122
#define SHORTPULSE      85
#define LONGPULSE       90
#define ACTIVEMODE      117
/*     Variables                           */
 
static bit RxData    @  PORTBIT(GPIO,3);    // Rxd > RB3
static bit s_length,setup_mode,receive;
unsigned char   pulse[6]; // position des 5 servo + tps repos
char x; 		  // indice des servo
unsigned char servo,result,sauve_option,car,valeur,octet_recu;
/*  Constantes            */

const unsigned char short_header[16]={19,28,38,46,55,64,73,83,91,100,109,118,127,136,145,154};
const unsigned char long_header[16]={15,23,30,38,45,53,61,68,75,83,91,98,105,113,120,128}; 

/************************************************************/	
void interrupt timer_isr(void);
unsigned char getch(void);
unsigned char calcul_tmr0(unsigned char valeur);
void init_header(unsigned char val);
void init_pic(void);
void init_servo(void);
void calibration(void);
void analyse(unsigned char valeur);
/************************************************************
	Programme principal
	- initialisation du pic12C671 et des variables
      - en boucle, lecture d'un caractere et traitement.
************************************************************/
		
void main(void)
{
	calibration();
	init_pic();
	init_servo();
   do
   {   
      car=getch();
      switch (car)
      {
	case SETUPMODE : setup_mode=ON;
			 break;

	case ACTIVEMODE: 	setup_mode=OFF;
			 	x=0;
	             	OPTION=sauve_option;
			  	GIE=1;        // commande des servo
	                 	break;
	case SHORTPULSE: 	if(setup_mode) 
	                 	{
		                  s_length=ON;
		                  sauve_option=DIV_8;
		                  x=0;
		         	}         
				 break;
	         		 
	case LONGPULSE:  	if(setup_mode)
				{
				  	s_length=OFF;
				  	sauve_option=DIV_16;
				  	x=0;
			 	}				  
			 	break;
        default       : analyse(car);
                        break;			      
        }
       

		if(!setup_mode) GIE=1; 
       	    
	
   }while(!0);		// le programme continue
}    



/************************************************************
		timer 0 interruption 
		commande les servos pendant un tps fonction 
		des valeurs contenues dans pulse[x]
		si setup_mode=1 ou si un caractere 
		est recu sur la liaison serie alors pas d'impulsion
		priorite � la RS232 simulee
************************************************************/

void interrupt
timer_isr(void) 
{
	if(receive || setup_mode)       //si reception d'un caractere
	{
		GPIO=0;   // plus d'impulsion
		T0IF=0;
		GIE=0;    // ni d'interruption
		asm("goto int_restore"); //restaure les registres
	}else
	{	
        OPTION=sauve_option;
        TMR0 += -pulse[x] ;	// charge le timer 0
        if (x<5)
        { 
        	if(x<3) GPIO = 1<<x;
            else
        	GPIO = 1<<(x+1);
	  }else  
        {
	         GPIO=0;
               sauve_option=OPTION;
               OPTION=DIV_256;            
               x=-1;
        }        

      }      
        x++;
       
	  T0IF=0;
      
}
//*******************************************************************
/*          fonction getch(): lecture d'un caractere sur
                              la liaison serie. A 2400 bits/S
                              la scrutation se fait  a trois reprises
					   !  !  !
					|-----------| toutes les 100 �S pd la 
					presence d'un bit et ce toutes les 400�S. 
                              (dly) 2400,N,8,1 
********************************************************************/ 
unsigned char getch(void)
{
unsigned char bitno, dly,caractere;
static bit Rx1,Rx2;


       
        while(RxData);  //Attente bit stop 
	for(;;) {
	while(!RxData)
		continue; // Attente bit start 
		dly = DELAY(30)/2;
		do;
		while(--dly);     // temporisation 1/2 start
	if(!RxData)
		continue; // Bruit
            receive=ON;
		bitno = 8;
		caractere = 0;
            dly = DELAY(RX_TEMPO)/4;      //100�S
		do;
		while(--dly);
	if(!RxData)
		continue; // Bruit 
		do {
		   
			dly = DELAY(RX_TEMPO)/2;   //200�S
			do;
			while(--dly);
			Rx1=RxData;
			dly = DELAY(RX_TEMPO)/4;   //100�S
			do;
			while(--dly);
			Rx2=RxData;
			dly = DELAY(RX_TEMPO)/4;   //100�S
			do;
			while(--dly);
		      Rx1 ^= Rx2;       
			if(Rx1)	Rx2=RxData; 
			caractere = (caractere >> 1) | (Rx2 << 7);
		

		} while(--bitno);
		receive=OFF;
		return (~caractere);
	}
}
/****************************************************
     Calcul_tmr0: Calcul a partir de la valeur
     passee en parametre la valeur correspondante
     a charger dans le timer0. le mode de fonctionnement
     short ou long_length determine la largeur de la fenetre
************************************************************/     
unsigned char calcul_tmr0(unsigned char valeur)
{
unsigned int a;
a=valeur*(s_length?(5):(9));
  if(s_length) 
  { 
	return (unsigned char)((a+600)/8);
  }else
  {
	return (unsigned char)((a+100)/16);
  }
}

/**********************************************************
	init_pic(): initialise les registres du pic12C671
	init_header : initialise la position des servos
      init_servo  : initialise les variables de mode de fonctionnement
	calibration : initialise OSCCAL pour calibrer INT OSC
***********************************************************/

void init_pic(void)
{
      sauve_option=DIV_8;     // predivise par 8
      TRIS = 0x8;	      // GPIO bits 012 45  output, bit 3 input
      GPIO =  0;              // Pas d'impulsion
      T0IE = 1;		      // valide interruption TMR0
}

void init_header(unsigned char val)
{
      for(x=0;x<5;x++) 
      {
         if(s_length)
            pulse[x]=short_header[val];
         else
            pulse[x]=long_header[val]; 
      }      
	x=0;
}		

void init_servo(void)
{

	s_length=ON;
	setup_mode=OFF;
	receive=OFF;
	init_header(12);
      pulse[5]= 90;      // tempo repos
	octet_recu=0;
	
}


void calibration(void)
{       
	asm("fcall 3FFh"); // lecture de calibration en 3FF
	asm("bsf 3,5");
	asm("movwf 15");   // et ecriture dans OSCCAL
}
/**********************************************************************
	analyse(): conversion des valeurs de commande en valeur timer0 (tps)
      en mode setup: lecture du premier octet de commande (bit 7 =0)
	puis du deuxi�me (bit 7 =1) et recuperation du numero du servo, 
	de la valeur tps a convertir. lecture de la valeur init_header
***********************************************************************/            
	
void analyse(unsigned char valeur)
{
unsigned char temp; 
    if(!setup_mode)
    {  
        temp=valeur;
        temp &= 0x80;
    	switch(temp)
    	{
        case 0 :	result = valeur;   			//premier byte
	    		servo  = (valeur>>=4) & 0x07;
    	          	result &= 0x0F;  			//sauve lower nibble
			octet_recu=1;
    	          	break; 
    	       	 
        case 0x80:  if(octet_recu==1)
		        {
			   octet_recu=0;
			   temp = valeur;	
	        	   result |= ((valeur<<=4) & 0xF0);
			   if((servo == ((temp >>=4) & 0x07)) && (servo<5))
    	  		   {
	    			pulse[servo]=calcul_tmr0(result);
				
	    		   } 		
		        }
   			break;     	
    	 default: break; 
	}	
    
    }else
    {  
    		temp=valeur;	    
		valeur&=0xF0;	    
       	if(valeur==0x60)
       	{
	  		temp &=0x0F;
	  		init_header(temp); 
       	}         
    	
    }
}    
