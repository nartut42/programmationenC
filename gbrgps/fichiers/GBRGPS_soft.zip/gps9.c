/*                      GPS 9
    --------------------------------------------------------
   |             REPETEUR GPS NMEA183 SANS FIL              |
   |               3 MENUS COMMANDES PAR UP DOWN            |
   |--------------------------------------------------------|
   |             Claudedel@microcontroleur.fr.st            |
    --------------------------------------------------------
*/

#include <gb\gb.h>
#include <gb\drawing.h>
#include <gb\font.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <hardware.h>
#include <tab_gps.c>



//**************************************************
void aff1(void);
void aff2(void);
void aff3(void);
void aff4(void);
void refresh_aff(UINT8 niveau);
void refresh_aff1(void);
void refresh_aff2(void);
void refresh_aff3(void);
UINT8 quel_cadran(UINT16 angle);
UINT8 coordonnees(UINT16 angle,UINT8 rayon);
void trace_nsew(void);
void point_nsew(UINT16 angle);
void fleche_droite(void);
void fleche_gauche(void);
void cls_lcd(void);
void init_sprites_chiffres(void);
UINT16 atoint16(char *s);
void trace_fleche(UINT16 angle);
void init_sprites(void);
void init_aff1(void);
void lecture_gps(void);
BOOLEAN lecture_chaine(void);
void init_param(void);
void intoa(int n,char *s);
void init_timer(void);
void tempo(void);
void tempo_chaine(void);
unsigned char copy_chaine(unsigned char pos,unsigned char n,char *s);
void format_lon(void);
void format_lat(void);
void format_angle(char *s);
BOOLEAN format_arrive(void);
//**************************************************
char waypoint[7],cap[6],dist[6],vit_fond[6];
char gis[6],lon[11],lon_EW[2],lat[12],lat_NS[2],dev[3],sens_dev[2];
char dif[4],arrive[2],direction[2];
char chaine[80];
UINT8 menu,x,y,num_fleche,sens;
UINT8 cadran;
BOOLEAN actu;
BOOLEAN touche_valide;
UBYTE *Pic_Rec;
BOOLEAN destination;
//**************************************************

void main()
{
char touche;    

  menu=0;
  actu=0;
  destination=0;
  touche_valide=0;
  init_sprites();
  num_fleche=0;
  Pic_Rec = (UBYTE *)0xA000;
  init_param();
  init_timer();
  aff1(); 
  
   
  do
  {
    
   
   if(*Pic_Rec == '#') lecture_gps();
   
   
   touche=joypad();
   if(touche)
   {
   	switch(touche)
   	{
   	case J_UP  : if(menu == 2) menu=0;
   					else menu++;
   				 touche_valide=1;
   				 break;
   	case J_DOWN: if(menu==0) menu=2;
   				 else menu--;
   				 touche_valide=1;
               	 break;   
    default:break;           	 
            	        
   } 
   if(touche_valide)
   {
        
   		switch(menu)
   		{
   		case 0: cls_lcd();
    				init_sprites();
    				aff1();
    				break;
   				
    		case 1: HIDE_SPRITES;
    				cls_lcd();
    				aff3();
    				break;
    		case 2: HIDE_SPRITES;
   					cls_lcd();
   					aff2();
   					break;
    		
    				
    	}
    	touche_valide=0;
    	
    }								
   }
   if(menu==0)
   {
   	
   		switch(sens)
   		{
   			case(1) :fleche_droite();
   					break;
   			case(2) :fleche_gauche();
   					break;
   			default:break;			
   		}
    			
   } 
   refresh_aff(menu);
   
   
   if(++num_fleche==5) num_fleche=0;	
  }while(!0);
}


void refresh_aff(UINT8 niveau)
{
	switch(niveau)
   	{
   			case 0: actu=1;
   					aff1();
   					actu=0;
   					switch(sens)
  			 		{
   						case(1) :fleche_droite();
   								break;
   						case(2) :fleche_gauche();
   								break;	
   						default:break;		
   					}
    				break;
   				
    		case 1: refresh_aff3();
    				break;
    		case 2: refresh_aff2();
   					break;
    				
    }								
}	
   		
   		
void init_param(void)
{
	strcpy(gis,"000");
	strcpy(waypoint,"XXXXXX");
	strcpy(cap,"000");
	strcpy(dist,"000.0");
	strcpy(vit_fond,"000");
	strcpy(lat,"000�00.00");
	strcpy(lat_NS,"N");
	strcpy(lon,"00�00.00");
	strcpy(lon_EW,"W");
	
}

//*****************************************************************
void init_timer(void)
{
	TMA_REG=0xFF;
	TAC_REG=5;

}

    
void tempo(void)
{

		TIMA_REG = 0;
		while (TIMA_REG <= 100); 
}



BOOLEAN lecture_chaine(void)
{
  //exemple "5815.53,N,00241.18,E,13.6,045.2,3,W,R,LORIEN,40.6,146.3,A,\0"
UINT8 temp,i;
BOOLEAN fin;
  temp=0;
  i=0;
  fin=0;
  
  
  *Pic_Rec=0;  // impulsion WR/A000
  tempo();
  tempo();
  	
  do
  {
  	   	temp = *Pic_Rec;
        chaine[i]=temp;
        if(chaine[i]== 0) fin=1;
        i++;
        *Pic_Rec=0;	// impulsion WR/A000
        tempo();
  }while(!fin);	//fin de chaine
    
   return(1);
    
    
}   


unsigned char copy_chaine(unsigned char pos,unsigned char n,char *s)
{
//"5815.53,N,00241.18,E,13.6,045.2,3,W,R,LORIEN,40.6,146.3,A,\0"
unsigned char x;
	x=0;
	do
	{
 		if(chaine[pos] != ',') s[x++] = chaine[pos++];
 		else break;
 			 
 	 }while( x != n); 
    
     if(x != n)
     while(x != n)
     {
     	s[x++]=' ';	
     }
     s[x]=0;	
     while(chaine[pos++] != ',');
 	return(pos);
}     



void lecture_gps()
{
unsigned char pos;
pos=0;
 //"5815.53,N,00241.18,E,13.6,045.2,3,W,R,LORIEN,40.6,146.3,A,\0"
 
  	if(lecture_chaine()==1)
  	{
    pos = copy_chaine(pos,7,lon);
    pos = copy_chaine(pos,1,lon_EW);
 	pos = copy_chaine(pos,8,lat);
  	pos = copy_chaine(pos,1,lat_NS);
  	pos = copy_chaine(pos,4,vit_fond);
  	pos = copy_chaine(pos,3,cap);
  	pos = copy_chaine(pos,1,dev);
  	pos = copy_chaine(pos,1,sens_dev);
  	pos = copy_chaine(pos,1,direction);
  	pos = copy_chaine(pos,6,waypoint);
  	pos = copy_chaine(pos,5,dist);
  	pos = copy_chaine(pos,3,gis);
  	pos = copy_chaine(pos,1,arrive);
  	format_lon();
  	format_lat();
    format_angle(cap);
    format_angle(gis);
    destination=format_arrive();
    }
    
}

void format_angle(char *s)
{
int c,result;
int d;
     c=atoint16(s);
	 d=atoint16(dev);
	 
	 if(sens_dev[0]=='W')
	 {
	  result=c+d;
	  if(result >= 360) result = (result -360); 
	 }else  
	 {
	 	result = c-d;
	 	if(result < 0) result = (360 + result);
	 }	
	 intoa(result,s);
	 c=strlen(s);
	 if(c < 3)	//ajoute des 0
	 {
	 	reverse(s);
	 	s[3]=0;
	 	do
	 	{	
	 		s[c++]='0';
	 	}while(c!=3);
	 	reverse(s);
	 }	
}


void format_lon(void)
{
unsigned char l;
	l=strlen(lon);
  	reverse(lon);
  	lon[l+2]=lon[l+1];
  	lon[l+1]=lon[l];
  	lon[l]=lon[l-1];
  	lon[l-1]=lon[l-2];
  	lon[l-2]='�';
  	reverse(lon);
}

void format_lat(void)
{
unsigned char l;
	l=strlen(lat);
  	reverse(lat);
  	lat[l+2]=lat[l+1];
  	lat[l+1]=lat[l];
  	lat[l]=lat[l-1];
  	lat[l-1]=lat[l-2];
  	lat[l-2]=lat[l-3];
  	lat[l-3]='�';
  	reverse(lat);
}

BOOLEAN format_arrive(void)
{
	BOOLEAN resultat;
	resultat=0;
	if(arrive[0] == 'A') resultat=1;
	return(resultat);
}	
//*****************************************************************

void init_sprites(void)
{

	set_sprite_data(0,11,neso);
   	SPRITES_8x8;
   	set_sprite_tile(1,0); 	//N
   	set_sprite_tile(2,1);	//E
   	set_sprite_tile(3,2);	//S
   	set_sprite_tile(4,3);	//W
   	set_sprite_tile(5,4);	//point
   	set_sprite_tile(6,4);	//point
   	set_sprite_tile(7,4);	//point
   	set_sprite_tile(8,4);	//point
  	set_sprite_tile(9,5);	//<<<
   	set_sprite_tile(10,6); //boule
   	set_sprite_tile(11,7); //trait
   	set_sprite_tile(12,7); //trait
   	set_sprite_tile(13,8); //fleche
   	set_sprite_tile(14,8);	//fleche
   	set_sprite_tile(15,8);	//fleche
   	set_sprite_tile(16,8);	//fleche
   	set_sprite_tile(17,9);	//fleche
   	set_sprite_tile(18,9);	//fleche
   	set_sprite_tile(19,9);	//fleche
   	set_sprite_tile(20,10);	//fleche
   	set_sprite_prop(1,0);
   	set_sprite_prop(2,0);
   	set_sprite_prop(3,0);
   	set_sprite_prop(4,0);
   	set_sprite_prop(5,0);
   	set_sprite_prop(6,0);
   	set_sprite_prop(7,0);
   	set_sprite_prop(8,0);
   	set_sprite_prop(9,0);
   	set_sprite_prop(10,0);
   	set_sprite_prop(11,0);
   	set_sprite_prop(12,0);
   	set_sprite_prop(13,0);	//fleche
   	set_sprite_prop(14,0);	//fleche
   	set_sprite_prop(15,0);	//fleche
   	set_sprite_prop(16,0);	//fleche
   	set_sprite_prop(17,0);	//fleche
   	set_sprite_prop(18,0);	//fleche
   	set_sprite_prop(19,0);	//fleche
   	set_sprite_prop(20,0);	//fleche
    	
} 

void cache_sprites(void)
{ 
UINT8 i;
 for(i=0; i < 4; i++) 
 {
	move_sprite(i, 0, 0);
  }
}
 

void aff1(void)
{  
 UINT16 angle,gisement,cap_suivi,dif_angle;
 UINT8 c;
    if(!actu)
    {
    	box(1,1,158,142,M_FILL);
   		box(3,3,156,20);
   		box(3,123,156,140);
   		line(4,123,4,140);
   		line(3,139,156,139);
   		line(4,3,4,20);
   		line(4,19,156,19);
   		move_sprite(11,85,40);
   		move_sprite(12,85,48);
   		move_sprite(10,85,84);
   		circle(80, 72, 48, M_NOFILL);
   	}	
   	
   	gisement=atoint16(gis);
    cap_suivi=atoint16(cap);
   if(atoint16(gis) >= atoint16(cap))
   {
       
       angle = (gisement-cap_suivi);
       if(angle<=180) dif_angle=angle;
       else dif_angle=(360-angle);
   }       
   else
   {
   		
   		angle = (360-(cap_suivi-gisement));
   		if(angle>=180) dif_angle=(cap_suivi-gisement);
   		else dif_angle=(gisement+(360-cap_suivi));
   	}

   	cadran = coordonnees(angle,34);
	trace_fleche(angle);
   	gotogxy(1,1);
    gprintf("%s",waypoint);
   
    if(angle==0)
   	{
   		gotogxy(8,1);
   		gprint("<<>>");
   		sens=0;
   	}else
   	{   
   		gotogxy(8,1);
   		gprint("    ");		
   		if((cadran==1) || (cadran==2)) 
   		{   
   			sens=1;
   			
   		}else 
   		{	
   			sens=2;
   		}

   		
   	}	
   		
   		
   		intoa(dif_angle,dif);
	 	c=strlen(dif);
	 	if(c < 3)	//ajoute des 0
	 	{
	 		reverse(dif);
	 		dif[3]=0;
	 		do
	 		{	
	 			dif[c++]='0';
	 		}while(c!=3);
	 		reverse(dif);
	 	}	
   	
   		gotogxy(13,1); 
   		gprintf("%s",dif);
   		gprint("�");	
   		trace_nsew(cadran);
   		if(!destination)
   		{
   			gotogxy(1,16);
   			gprintf("gis:%s� > %snm",gis,dist);
      	
   		}else
   		{
   			gotogxy(1,16);
   			gprintf(" DESTINATION = OK ");
   		}	
   		
   			
   		SHOW_SPRITES;
}


void aff2(void)
{  

   box(3,9,157,140);
   box(5,11,155,138);
   gotogxy(5,1);
   gprint(" POSITION ");
   gotogxy(2,5);
   gprintf("Lat : %s",lat);
   gprint(lat_NS);
   gotogxy(2,7);
   gprintf("Long:  %s",lon);
   gprint(lon_EW);
   gotogxy(2,12);
   gprintf("Cap     : %s�",cap);
   gotogxy(2,14);
   gprintf("Vitesse : %s kt",vit_fond);
  
}


void refresh_aff2(void)
{
   gotogxy(8,5);
   gprintf("%s ",lat);
   gprintf(lat_NS);
   gotogxy(9,7);
   gprintf("%s ",lon);
   gprintf(lon_EW);
   gotogxy(12,12);
   gprintf("%s�",cap);
   gotogxy(12,14);
   gprintf("%s kt",vit_fond);
   

}

void aff3(void)
{  
   box(3,9,157,70);
   box(5,11,155,68);
   gotogxy(5,1);
   gprintf(" WAYPOINT ");
   gotogxy(3,3);
   if(direction[0]=='L') gprintf("    %s <<<",waypoint);
   else if(direction[0]=='R') gprintf(">>> %s",waypoint);
   else gprintf("    %s    ",waypoint);
   gotogxy(2,5);
   gprintf("Gisement:%s�",gis);
   gotogxy(2,7);
   gprintf("Distance:%s nm",dist);
   box(3,80,157,142);
   box(5,82,155,140); 
   gotogxy(6,10);
   gprintf(" ROUTE ");
   gotogxy(2,12);
   gprintf("Cap     :%s�",cap);
   gotogxy(2,14);
   gprintf("Vitesse :%s kt",vit_fond);
   
}   

void refresh_aff3(void)
{
   gotogxy(3,3);
   if(direction[0]=='L') gprintf("    %s <<<",waypoint);
   else if(direction[0]=='R') gprintf(">>> %s",waypoint);
   else gprintf("    %s    ",waypoint);
   gotogxy(11,5);
   gprintf("%s�",gis);
   gotogxy(11,7);
   gprintf("%s nm",dist);
   gotogxy(11,12);
   gprintf("%s�",cap);
   gotogxy(11,14);
   gprintf("%s kt",vit_fond);
   
}

void fleche_droite(void)
{
	set_sprite_prop(9,0);
    switch(num_fleche)
	{
   		case(0):move_sprite(9,75,25);
        	    break;
        case(1):move_sprite(9,82,25);
            	break;
   		case(2):move_sprite(9,89,25);
   				break;
   		case(3):move_sprite(9,96,25);
   				break;
   		case(4):move_sprite(9,0,160);
   				break;
   	}	
}   

void fleche_gauche(void)
{

	set_sprite_prop(9,0+32);
	switch(num_fleche)
	{
   		case(0):move_sprite(9,96,25);
        	    break;
    	case(1):move_sprite(9,89,25);
        	    break;
    	case(2):move_sprite(9,82,25);
   				break;
   		case(3):move_sprite(9,75,25);
   				break;
   		case(4):move_sprite(9,0,160);
   				break;
   	}		
}   
    
void point_nsew(UINT16 angle)
{
UINT8 z,null;
		for(z=0;z!=4;z++)
		{
			null=coordonnees(angle,47);
		    x+=5;
		    y+=13;
		    move_sprite(5+z,x,y);
		    null=coordonnees(angle,37);
		    x+=5;
		    y+=12;
		    switch(cadran+z)
		    {
		    	case 1:	move_sprite(2,x,y);   	//trace_est
		    		    break;
		    	case 2:	move_sprite(3,x,y);   	//trace_sud
		    			break;
		    	case 3:	move_sprite(4,x,y);		//trace_ouest
		    			break;	   
		    	case 4:	move_sprite(1,x,y);		//trace_nord
		    			break; 	
		    	case 5:	move_sprite(2,x,y);		//trace_est
		    			break;	
		    	case 6:	move_sprite(3,x,y);		//trace_sud;
		    			break;
		    	case 7:	move_sprite(4,x,y);		//trace_ouest;
		    			break;					
		    }
		   	angle+=90;
		}	
}

void trace_nsew(void)
{
UINT16 angle,ref_zero;

    ref_zero=atoint16(cap);
   	cadran = coordonnees(ref_zero,48);
  switch(cadran)
  {
   case 1: 	angle=(90-ref_zero);
           	break;
   case 2: 	angle=(180-ref_zero);
   		   	break;
   case 3: 	angle=(270-ref_zero);
   		  	break;
   case 4: 	angle=(360-ref_zero);
   			break;
  }		
  			point_nsew(angle);
}  

	    	 
UINT8 quel_cadran(UINT16 angle)
{
INT8 n;

	n=0;
do
{
	if(angle == 270)n=4;
	if(angle == 180)n=3;
	if(angle == 90) n=2;
	if(angle == 0)  n=1;
	angle--;
}while(!n);	
	
     return(n);
}

UINT8 coordonnees(UINT16 angle,UINT8 rayon)
{
UINT8 cadran;
  cadran = quel_cadran(angle);
 switch(cadran)
   {
   
   		case 1: x=80+((rayon*(unsigned int)tablesin[angle])/1000);
   				y=72-((rayon*(unsigned int)tablesin[(90-angle)])/1000); 
  				break;
  		case 2:	x=80+((rayon*(unsigned int)tablesin[(180-angle)])/1000);
   				y=72+((rayon*(unsigned int)tablesin[(angle-90)])/1000);
   				break;
   		case 3: x=80-((rayon*(unsigned int)tablesin[(angle-180)])/1000);
   				y=72+((rayon*(unsigned int)tablesin[(270-angle)])/1000);			
  				break;
  		case 4: x=80-((rayon*(unsigned int)tablesin[(360-angle)])/1000);
   				y=72-((rayon*(unsigned int)tablesin[(angle-270)])/1000);
   				break;
   }

   return(cadran);
}  

void trace_fleche(UINT16 angle)
{
UINT8 z,pas;
	
  pas=13;
  for(z=4;z!=44;z+=5)
  {
  	coordonnees(angle,z);
  	x+=5;
  	y+=12;
  	move_sprite(pas,x,y);
    pas++;
   } 
}  

void cls_lcd(void)
{
int y;

    for(y = 0; y < 19; y++)        
    {    
      gotogxy(0, y);              
      gprintf("                    ");              
    }                           
    gotogxy(0,0);
 
}



UINT16 atoint16(char *s)
{
  UINT8 i;
  UINT16 n;
   n=0;
   for(i = 0; isdigit(s[i]); ++i)
   n = 10 * n + s[i] - '0';
   return (n);
}

void intoa(int n,char *s)
{
  UINT8 i;
  i = 0;
  if(n==0) s[i++]='0';
  else
  {
     do 
     {
      s[i++] = n % 10 + '0';
      n = (n/10);
     }while(n != 0);
  }
  s[i] = 0;
  reverse(s);
}

