/*********************************************************************
*	Claudedel@wanadoo.fr
*	http://www.geocities.com/claudedel/
*	http://perso.wanadoo.fr/claude.dreschel/
********************************************************************/

#include	<pic1687x.h>
#include        "delay.h"

#define REF_5V		128
#define REF_2_5V   	129
#define INIT_PORTA      TRISA = 0x3F       //PortA = entrees
//**************************************************************************
void init_pic(void);
unsigned int mesure(unsigned char ADC_channel);
//************************************************************************
void main(void)
{

unsigned int valeur1,valeur2,valeur3;

init_pic();
valeur1 = mesure(1);  //mesure du canal 1
valeur2 = mesure(2); //mesure du canal 2
ADCON1=REF_2_5V; // ref = 2,5v 
valeur3 = mesure(3); // mesure du canal 3
while(!0); // fin

}

//**************************************************************
void init_pic(void)
{     
      INIT_PORTA;	
      ADCON1=REF_5V;  //ADFM=1 VREF=+5V
      ADIE=0;
      ADCS1=1;
      ADON=1;
}
//**************************************************************
unsigned int mesure(unsigned char ADC_channel)
{
unsigned int valeur;
      ADCON0 = (ADC_channel << 3)+ 129;
      DelayMs(5);
      valeur=0;
      ADIF=0;
      ADGO=1;
      while(!ADIF);
      valeur = ADRESL;
      valeur +=(ADRESH << 8);
      return(valeur);
}
//****************************************************************


