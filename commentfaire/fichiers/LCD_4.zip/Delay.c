/*
 *	Delay.c
 *	Delay.h 
 *      delais de 100uS, 250mS et X fois 250mS
 *	Attention compiler en "full optimization"
 */ 

#include	"delay.h"
#define	XTAL_FREQ 12 /* frequence en MHz */

void Delay100Us(void)
{
unsigned char  _dcnt;
	_dcnt=100/(12/XTAL_FREQ);
	while(--_dcnt) continue;
}		
	 
void Delay250Us(void)
{
unsigned char  _dcnt;
	_dcnt=250/(12/XTAL_FREQ);
	while(--_dcnt) continue;
}		

void
DelayMs(unsigned char cnt)
{
unsigned char	i;
	do {
		i = 4;
		do {
			Delay250Us();
		} while(--i);
	} while(--cnt);
}
