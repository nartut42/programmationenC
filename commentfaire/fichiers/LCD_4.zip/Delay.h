/*
 *	Delay fonctions d'attente
 */

extern void DelayMs(unsigned char);
extern void Delay250Us(void);
extern void Delay100Us(void);
