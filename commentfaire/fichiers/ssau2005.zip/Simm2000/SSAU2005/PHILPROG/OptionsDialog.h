#if !defined(AFX_OPTIONSDIALOG_H__59BF28C2_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_)
#define AFX_OPTIONSDIALOG_H__59BF28C2_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionsDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionsDialog dialog

class COptionsDialog : public CDialog
{
// Construction
public:
	COptionsDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COptionsDialog)
	enum { IDD = IDD_OPTIONS };
	CButton	m_SEC2;
	CButton	m_SEC1;
	CButton	m_WDTE;
	CButton	m_RPD;
	CButton	m_PRHI;
	CButton	m_BO25;
	CButton	m_CLKR;
	CButton	m_FOSC2;
	CButton	m_FOSC1;
	CButton	m_FOSC0;
	CButton	m_PortButton1;
	CButton	m_PortButton2;
	CButton	m_PortButton3;
	CButton	m_PortBox;
	//}}AFX_DATA
public:
	int m_nSelectedPort;
	BYTE m_SelectedConfig;
	BYTE m_SelectedSecurity;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COptionsDialog)
	afx_msg void OnLpt2();
	afx_msg void OnLpt3();
	afx_msg void OnLpt1();
	virtual BOOL OnInitDialog();
	afx_msg void OnFosc0();
	afx_msg void OnFosc1();
	afx_msg void OnFosc2();
	afx_msg void OnClkr();
	afx_msg void OnBo25();
	afx_msg void OnPrhi();
	afx_msg void OnRpd();
	afx_msg void OnWdte();
	afx_msg void OnSec1();
	afx_msg void OnSec2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSDIALOG_H__59BF28C2_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_)
