#if !defined(AFX_PROGRAMMER_H__6A5963E0_370E_11D4_A4E0_B46001C10000__INCLUDED_)
#define AFX_PROGRAMMER_H__6A5963E0_370E_11D4_A4E0_B46001C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Programmer.h : header file
//

#include "buffer.h"
#include "portint.h"
#include "wait.h"

// Programming commands for Philips 87LPC76X chip
#define NOP			0x00
#define LOAD_DATA	0x02
#define READ_DATA	0x04
#define INC_ADDR	0x06
#define LD_ADDR_LO	0x08
#define LD_ADDR_HI	0x0A
#define STRT_PRGM	0x0C
#define STOP_PRGM	0x0E

/////////////////////////////////////////////////////////////////////////////
// CProgrammer object

class CProgrammer : public CObject
{
// Construction
public:
	CProgrammer();

// Attributes
public:

private:
	PortInterface ProgrammerPort;
	Wait ProgrammerTimer;
	BYTE PortByte;
	int nEpromLength;

// Operations
public:
	CString IdentifyChip(int port);
	void ProgramFromBuffer (CBuffer* Buffer, int port);
	void ReadToBuffer(CBuffer* Buffer, int port );
	BOOL VerifyWithBuffer(CBuffer* Buffer, int port);
	void SetSafeMode(int port);
	BOOL ProgramFuses(BYTE Config, BYTE Security, int port);

private:
	void SendByte(BYTE data);
	BYTE GetByte();
	int SetProgramMode(int port);
	void EnableVpp(BOOL bState);
	void EnableVdd(BOOL bState);
	void SetPDA(BOOL State);
	void SetPCL(BOOL State);
	BOOL ReadPDA();

// Implementation
public:
	virtual ~CProgrammer();

};

#endif // !defined(AFX_PROGRAMMER_H__6A5963E0_370E_11D4_A4E0_B46001C10000__INCLUDED_)
