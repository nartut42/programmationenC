// philprogView.cpp : implementation of the CPhilprogView class
//

#include "stdafx.h"
#include "philprog.h"

#include "philprogDoc.h"
#include "philprogView.h"
#include "OptionsDialog.h"
#include "buffer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhilprogView

IMPLEMENT_DYNCREATE(CPhilprogView, CView)

BEGIN_MESSAGE_MAP(CPhilprogView, CView)
	//{{AFX_MSG_MAP(CPhilprogView)
	ON_COMMAND(ID_PROGRAMMING_IDENTIFY, OnProgrammingIdentify)
	ON_COMMAND(ID_PROGRAMMING_OPTIONS, OnProgrammingOptions)
	ON_COMMAND(ID_PROGRAMMING_PROGRAMCHIP, OnProgrammingProgramchip)
	ON_COMMAND(ID_PROGRAMMING_READCHIP, OnProgrammingReadchip)
	ON_COMMAND(ID_PROGRAMMING_VERIFYCHIP, OnProgrammingVerifychip)
	ON_COMMAND(ID_PROGRAMMING_PROGRAMFUSES, OnProgrammingProgramfuses)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhilprogView construction/destruction

CPhilprogView::CPhilprogView()
{
	// TODO: add construction code here
}

CPhilprogView::~CPhilprogView()
{
}

BOOL CPhilprogView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPhilprogView drawing

void CPhilprogView::OnDraw(CDC* pDC)
{
	CPhilprogDoc* pDoc = GetDocument();
	
	ASSERT_VALID(pDoc);
	TEXTMETRIC tm;
	CPoint ptText(0,0);
	int nIndex = 0;

	CGdiObject* pOldFont = pDC->SelectStockObject(ANSI_FIXED_FONT);

	pDC->GetTextMetrics(&tm);
	int nLineHeight = tm.tmHeight + tm.tmExternalLeading;
	while(nIndex < pDoc->Buffer1.GetSize())
	{
		CString s1;
		CString s2;
		s2.Format("%04X:",nIndex);
		s1 += s2;
		for(int nColumn = 0; (nColumn < 16) && (nIndex < pDoc->Buffer1.GetSize()); nColumn++)
		{
			BYTE byte = pDoc->Buffer1.GetAt(nIndex);
			s2.Format("%02X ", byte);
			s1 += s2;
			nIndex++;
		}
		pDC->TextOut(ptText.x, ptText.y, s1);
		ptText.y += nLineHeight;
	}
	pDC->SelectObject(pOldFont);
}

/////////////////////////////////////////////////////////////////////////////
// CPhilprogView diagnostics

#ifdef _DEBUG
void CPhilprogView::AssertValid() const
{
	CView::AssertValid();
}

void CPhilprogView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPhilprogDoc* CPhilprogView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPhilprogDoc)));
	return (CPhilprogDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPhilprogView message handlers


void CPhilprogView::OnProgrammingIdentify() 
{
	extern CPhilprogApp theApp;
	CString s1 = theApp.Programmer.IdentifyChip(theApp.m_nCurrentPort);

	AfxMessageBox(s1);
}

void CPhilprogView::OnProgrammingOptions() 
{
	COptionsDialog OptionsDialog;
	extern CPhilprogApp theApp;

	if (OptionsDialog.DoModal() == IDOK)
	{
		theApp.m_nCurrentPort = OptionsDialog.m_nSelectedPort;
		theApp.m_ConfigBits = OptionsDialog.m_SelectedConfig;
		theApp.m_SecurityBits = OptionsDialog.m_SelectedSecurity;
		theApp.WriteProfileInt("Settings", "Current Port", theApp.m_nCurrentPort);
		theApp.WriteProfileInt("Settings", "Config Bits", theApp.m_ConfigBits);
		theApp.WriteProfileInt("Settings", "Security Bits", theApp.m_SecurityBits);
	}
}

void CPhilprogView::OnProgrammingProgramchip() 
{
	extern CPhilprogApp theApp;
	CPhilprogDoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	theApp.DoWaitCursor(1);
	if (AfxMessageBox("Program chip. Are your sure?", MB_YESNO) == IDYES)
	{
		theApp.Programmer.ProgramFromBuffer(&pDoc->Buffer1, theApp.m_nCurrentPort);	

		if(theApp.Programmer.VerifyWithBuffer(&pDoc->Buffer1, theApp.m_nCurrentPort) == TRUE)
		{
			AfxMessageBox("Verify successful!");
		}
		else
		{
			AfxMessageBox("Verify failed");
		}

		if (AfxMessageBox("Program fuses?", MB_YESNO) == IDYES)
		{
			if (theApp.Programmer.ProgramFuses(theApp.m_ConfigBits, theApp.m_SecurityBits, theApp.m_nCurrentPort) == FALSE)
			{
				AfxMessageBox("Fuse programming failed");
			}
		}
	}
}
void CPhilprogView::OnProgrammingReadchip() 
{
	extern CPhilprogApp theApp;
	CPhilprogDoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	theApp.DoWaitCursor(1);
	theApp.Programmer.ReadToBuffer(&pDoc->Buffer1, theApp.m_nCurrentPort);
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(NULL);
}

void CPhilprogView::OnProgrammingVerifychip() 
{
	extern CPhilprogApp theApp;
	CPhilprogDoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	theApp.DoWaitCursor(1);
	if(theApp.Programmer.VerifyWithBuffer(&pDoc->Buffer1, theApp.m_nCurrentPort) == TRUE)
	{
		AfxMessageBox("Verify successful!");
	}
	else
	{
		AfxMessageBox("Verify failed");
	}
}

void CPhilprogView::OnProgrammingProgramfuses() 
{
	extern CPhilprogApp theApp;

	if (AfxMessageBox("Program fuses. Are you sure?", MB_YESNO) == IDYES)
	{
		if (theApp.Programmer.ProgramFuses(theApp.m_ConfigBits, theApp.m_SecurityBits, theApp.m_nCurrentPort) == FALSE)
		{
			AfxMessageBox("Programming fuses failed");
		}
	}
}
