#if !defined(AFX_SCROLLDISPLAY_H__7D1524E0_416F_11D4_A4E0_B46001C10000__INCLUDED_)
#define AFX_SCROLLDISPLAY_H__7D1524E0_416F_11D4_A4E0_B46001C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScrollDisplay.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScrollDisplay form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CScrollDisplay : public CFormView
{
protected:
	CScrollDisplay();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CScrollDisplay)

// Form Data
public:
	//{{AFX_DATA(CScrollDisplay)
	enum { IDD = IDD_FORMVIEW };
	CListBox	m_lbDisplay;
	//}}AFX_DATA

// Attributes
public:
	CPhilprogDoc* GetDocument();


// Operations
public:
	void OnDraw(CDC* pDC);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScrollDisplay)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CScrollDisplay();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CScrollDisplay)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

inline CPhilprogDoc* CScrollDisplay::GetDocument()
   { return (CPhilprogDoc*)m_pDocument; }

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCROLLDISPLAY_H__7D1524E0_416F_11D4_A4E0_B46001C10000__INCLUDED_)
