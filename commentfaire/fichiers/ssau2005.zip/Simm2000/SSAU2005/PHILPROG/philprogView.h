// philprogView.h : interface of the CPhilprogView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHILPROGVIEW_H__2DAD40CC_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_)
#define AFX_PHILPROGVIEW_H__2DAD40CC_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPhilprogView : public CView
{
protected: // create from serialization only
	CPhilprogView();
	DECLARE_DYNCREATE(CPhilprogView)

// Attributes
public:
	CPhilprogDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhilprogView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPhilprogView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPhilprogView)
	afx_msg void OnProgrammingIdentify();
	afx_msg void OnProgrammingOptions();
	afx_msg void OnProgrammingProgramchip();
	afx_msg void OnProgrammingReadchip();
	afx_msg void OnProgrammingVerifychip();
	afx_msg void OnProgrammingProgramfuses();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in philprogView.cpp
inline CPhilprogDoc* CPhilprogView::GetDocument()
   { return (CPhilprogDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHILPROGVIEW_H__2DAD40CC_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_)
