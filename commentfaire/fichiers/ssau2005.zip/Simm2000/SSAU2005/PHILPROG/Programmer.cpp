// Programmer.cpp : implementation file
//

#include "stdafx.h"
#include "philprog.h"
#include "Programmer.h"
#include "portint.h"
#include "errcode.h"
#include "buffer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgrammer
CProgrammer::CProgrammer()
{
	PortByte = 0xFF;
	if(ProgrammerTimer.CheckHwTimer() == FALSE)
	{
		AfxMessageBox("Warning: Slow CPU");
	}
}

CProgrammer::~CProgrammer()
{
}

CString CProgrammer::IdentifyChip(int port)
{
	if (SetProgramMode(port) == OK)
	{
		ProgrammerPort.OpenParallel(port);
		SendByte(LD_ADDR_LO);
		SendByte(0x60);
		SendByte(LD_ADDR_HI);
		SendByte(0xFC);
		SendByte(READ_DATA);		
		int nID = GetByte();
		ProgrammerPort.CloseParallel();
		SetSafeMode(port);

		CString szID;

		switch (nID)
		{
		case 0x00:
			szID = "P87LPC764";
			nEpromLength = 0x1000;
			break;
		case 0x03:
			szID = "P87LPC762";
			nEpromLength = 0x800;
			break;
		case 0x07:
			szID = "P87LPC764";
			nEpromLength = 0x1000;
			break;
		default:
			szID = "Unknown chip type";
			nEpromLength = 0x2000;
			break;
		}
		return szID;
	}
	else
	{
		return "ID Failed: No port";
	}
}

void CProgrammer::SendByte(BYTE data)
{
	for (int nIndex = 0; nIndex < 8; nIndex++)
	{
		SetPCL(FALSE);
		ProgrammerTimer.WaitUsec(1);
		if ((data & 0x01) == 0x00)
		{
			SetPDA(FALSE);
		}
		else
		{
			SetPDA(TRUE);
		}
		SetPCL(TRUE);
		ProgrammerTimer.WaitUsec(1);
		data >>= 1;
	}
	ProgrammerTimer.WaitUsec(2);
}

BYTE CProgrammer::GetByte()
{
	BYTE data = 0;

	SetPDA(TRUE);
	for (int nIndex = 0; nIndex < 8; nIndex++)
	{
		SetPCL(FALSE);
		ProgrammerTimer.WaitUsec(1);
		data >>= 1;
		if (ReadPDA() == 0)
		{
			data &= 0x7F;
		}
		else
		{
			data |= 0x80;
		}
		SetPCL(TRUE);
		ProgrammerTimer.WaitUsec(1);
	}
	ProgrammerTimer.WaitUsec(2);
	return data;
}

void CProgrammer::ProgramFromBuffer (CBuffer* pBuffer, int port)
{
	IdentifyChip(port);

	if (SetProgramMode(port) == OK)
	{
		if (nEpromLength < pBuffer->GetSize())
		{
			AfxMessageBox("Chip EPROM too small for binary!");
		}
		else
		{
			ProgrammerPort.OpenParallel(port);
			SendByte(LD_ADDR_LO);
			SendByte(0x00);
			SendByte(LD_ADDR_HI);
			SendByte(0x00);
			for	(int nIndex = 0; nIndex < pBuffer->GetSize(); nIndex++)
			{
				SendByte(LOAD_DATA);
				SendByte(pBuffer->GetAt(nIndex));
				SendByte(STRT_PRGM);
				ProgrammerTimer.WaitUsec(250);
				SendByte(STOP_PRGM);
				SendByte(INC_ADDR);
			}
			ProgrammerPort.CloseParallel();
		}
		SetSafeMode(port);
	}
	else
	{
		AfxMessageBox("Failed to open port");
	}
}

void CProgrammer::ReadToBuffer(CBuffer* pBuffer, int port)
{
	IdentifyChip(port);

	if (SetProgramMode(port) == OK)
	{
		pBuffer->RemoveAll();
		ProgrammerPort.OpenParallel(port);
		SendByte(LD_ADDR_LO);
		SendByte(0x00);
		SendByte(LD_ADDR_HI);
		SendByte(0x00);
		for (int nIndex = 0; nIndex < nEpromLength; nIndex++)
		{
			SendByte(READ_DATA);
			pBuffer->SetAtGrow(nIndex, GetByte());
			SendByte(INC_ADDR);
		}
		ProgrammerPort.CloseParallel();
		SetSafeMode(port);
	}
	else
	{
		AfxMessageBox("Failed to open port");
	}
}

BOOL CProgrammer::VerifyWithBuffer(CBuffer* pBuffer, int port)
{
	if (SetProgramMode(port) == OK)
	{
		ProgrammerPort.OpenParallel(port);
		SendByte(LD_ADDR_LO);
		SendByte(0x00);
		SendByte(LD_ADDR_HI);
		SendByte(0x00);
		for (int nIndex = 0; nIndex < pBuffer->GetSize(); nIndex++)
		{
			SendByte(READ_DATA);
			if (pBuffer->GetAt(nIndex) != GetByte())
			{
				ProgrammerPort.CloseParallel();
				SetSafeMode(port);
				return FALSE;
			}
			SendByte(INC_ADDR);
		}
		ProgrammerPort.CloseParallel();
		SetSafeMode(port);
		return TRUE;
	}
	else
	{
		AfxMessageBox("Failed to open port");
		return FALSE;
	}
}

BOOL CProgrammer::ProgramFuses(BYTE Config, BYTE Security, int port)
{
	BOOL RetVal = TRUE;

	if (SetProgramMode(port) == OK)
	{
		ProgrammerPort.OpenParallel(port);
		SendByte(LD_ADDR_LO);
		SendByte(0x00);
		SendByte(LD_ADDR_HI);
		SendByte(0xFD);

		SendByte(LOAD_DATA);
		SendByte(Config);
		SendByte(STRT_PRGM);
		ProgrammerTimer.WaitUsec(250);
		SendByte(STOP_PRGM);
		SendByte(READ_DATA);
		if (GetByte() != Config) RetVal = FALSE;
		SendByte(INC_ADDR);

		SendByte(LOAD_DATA);
		SendByte(Security);
		SendByte(STRT_PRGM);
		ProgrammerTimer.WaitUsec(250);
		SendByte(STOP_PRGM);
		SendByte(READ_DATA);
		if (GetByte() != Security) RetVal = FALSE;

		ProgrammerPort.CloseParallel();
		SetSafeMode(port);
	}
	else
	{
		AfxMessageBox("Failed to open port");
	}
	return RetVal;
}

int CProgrammer::SetProgramMode(int port)
{
	int nRetVal = ProgrammerPort.OpenParallel(port);
	if (nRetVal == OK)
	{
		SetPCL(TRUE);
		SetPDA(TRUE);
		EnableVdd(TRUE);
		ProgrammerTimer.WaitUsec(20);
		EnableVpp(TRUE);
		ProgrammerTimer.WaitUsec(60);
		ProgrammerPort.CloseParallel();
	}
	return nRetVal;
}

void CProgrammer::SetSafeMode(int port)
{
	if (ProgrammerPort.OpenParallel(port) == OK)
	{
		EnableVpp(FALSE);
		EnableVdd(FALSE);
		SetPDA(FALSE);
		SetPCL(FALSE);
		ProgrammerPort.CloseParallel();
	}
}

void CProgrammer::EnableVpp(BOOL bState)
{
	if (bState == TRUE)
	{
		PortByte &= 0xFE;
		ProgrammerPort.OutPort(PortByte);

	}
	else
	{
		PortByte |= 0x01;
		ProgrammerPort.OutPort(PortByte);
	}
}

void CProgrammer::EnableVdd(BOOL bState)
{
	if (bState == TRUE)
	{
		PortByte &= 0xFD;
		ProgrammerPort.OutPort(PortByte);

	}
	else
	{
		PortByte |= 0x02;
		ProgrammerPort.OutPort(PortByte);
	}
}

void CProgrammer::SetPDA(BOOL bState)
{
	if (bState == FALSE)
	{
		PortByte &= 0xF7;
		ProgrammerPort.OutPort(PortByte);
	}
	else
	{
		PortByte |= 0x08;
		ProgrammerPort.OutPort(PortByte);
	}

}

void CProgrammer::SetPCL(BOOL bState)
{
	if (bState == FALSE)
	{
		PortByte &= 0xFB;
		ProgrammerPort.OutPort(PortByte);
	}
	else
	{
		PortByte |= 0x04;
		ProgrammerPort.OutPort(PortByte);
	}
}

BOOL CProgrammer::ReadPDA()
{
	if ((ProgrammerPort.InPort() & 0x40) == 0x00)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CProgrammer message handlers