// philprogDoc.cpp : implementation of the CPhilprogDoc class
//

#include "stdafx.h"
#include "philprog.h"
#include "philprogDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhilprogDoc

IMPLEMENT_DYNCREATE(CPhilprogDoc, CDocument)

BEGIN_MESSAGE_MAP(CPhilprogDoc, CDocument)
	//{{AFX_MSG_MAP(CPhilprogDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhilprogDoc construction/destruction

CPhilprogDoc::CPhilprogDoc()
{
}

CPhilprogDoc::~CPhilprogDoc()
{
}

BOOL CPhilprogDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// (SDI documents will reuse this document)
	Buffer1.RemoveAll();
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPhilprogDoc serialization

void CPhilprogDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		Buffer1.Serialize(ar);
	}
	else
	{
		Buffer1.Serialize(ar);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPhilprogDoc diagnostics

#ifdef _DEBUG
void CPhilprogDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPhilprogDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPhilprogDoc commands
