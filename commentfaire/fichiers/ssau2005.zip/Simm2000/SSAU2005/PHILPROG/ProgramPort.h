#if !defined(AFX_PROGRAMPORT_H__59BF28C3_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_)
#define AFX_PROGRAMPORT_H__59BF28C3_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgramPort.h : header file
//
#include "portint.h"

/////////////////////////////////////////////////////////////////////////////
// CProgramPort window

class CProgramPort : public PortInterface
{
// Construction
public:
	CProgramPort();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgramPort)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProgramPort();

	// Generated message map functions
protected:
	//{{AFX_MSG(CProgramPort)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRAMPORT_H__59BF28C3_2E6D_11D4_97BC_44C1FCC00000__INCLUDED_)
