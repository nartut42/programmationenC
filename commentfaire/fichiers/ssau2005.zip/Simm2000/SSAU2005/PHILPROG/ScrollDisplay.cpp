// ScrollDisplay.cpp : implementation file
//

#include "stdafx.h"
#include "philprog.h"
#include "philprogDoc.h"
#include "ScrollDisplay.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScrollDisplay

IMPLEMENT_DYNCREATE(CScrollDisplay, CFormView)

CScrollDisplay::CScrollDisplay()
	: CFormView(CScrollDisplay::IDD)
{
	//{{AFX_DATA_INIT(CScrollDisplay)
	//}}AFX_DATA_INIT
}

CScrollDisplay::~CScrollDisplay()
{
}

void CScrollDisplay::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScrollDisplay)
	DDX_Control(pDX, IDC_LIST, m_lbDisplay);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScrollDisplay, CFormView)
	//{{AFX_MSG_MAP(CScrollDisplay)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScrollDisplay diagnostics

#ifdef _DEBUG
void CScrollDisplay::AssertValid() const
{
	CFormView::AssertValid();
}

void CScrollDisplay::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

void CScrollDisplay::OnDraw(CDC* pDC)
{
	CPhilprogDoc* pDoc = GetDocument();
	
	ASSERT_VALID(pDoc);
	int nIndex = 0;

	m_lbDisplay.AddString("test");
/*
	while(nIndex < pDoc->Buffer1.GetSize())
	{
		CString s1;
		CString s2;
		s2.Format("%04X:",nIndex);
		s1 += s2;
		for(int nColumn = 0; (nColumn < 16) && (nIndex < pDoc->Buffer1.GetSize()); nColumn++)
		{
			BYTE byte = pDoc->Buffer1.GetAt(nIndex);
			s2.Format("%02X ", byte);
			s1 += s2;
			nIndex++;
		}
		m_lbDisplay.AddString(s1);
	}*/
}

/////////////////////////////////////////////////////////////////////////////
// CScrollDisplay message handlers
