// OptionsDialog.cpp : implementation file
//

#include "stdafx.h"
#include "philprog.h"
#include "OptionsDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDialog dialog


COptionsDialog::COptionsDialog(CWnd* pParent /*=NULL*/)
	: CDialog(COptionsDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionsDialog)
	//}}AFX_DATA_INIT
}


void COptionsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsDialog)
	DDX_Control(pDX, IDC_SEC2, m_SEC2);
	DDX_Control(pDX, IDC_SEC1, m_SEC1);
	DDX_Control(pDX, IDC_WDTE, m_WDTE);
	DDX_Control(pDX, IDC_RPD, m_RPD);
	DDX_Control(pDX, IDC_PRHI, m_PRHI);
	DDX_Control(pDX, IDC_BO25, m_BO25);
	DDX_Control(pDX, IDC_CLKR, m_CLKR);
	DDX_Control(pDX, IDC_FOSC2, m_FOSC2);
	DDX_Control(pDX, IDC_FOSC1, m_FOSC1);
	DDX_Control(pDX, IDC_FOSC0, m_FOSC0);
	DDX_Control(pDX, IDC_LPT1, m_PortButton1);
	DDX_Control(pDX, IDC_LPT2, m_PortButton2);
	DDX_Control(pDX, IDC_LPT3, m_PortButton3);
	DDX_Control(pDX, IDC_PORT, m_PortBox);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsDialog, CDialog)
	//{{AFX_MSG_MAP(COptionsDialog)
	ON_BN_CLICKED(IDC_LPT2, OnLpt2)
	ON_BN_CLICKED(IDC_LPT3, OnLpt3)
	ON_BN_CLICKED(IDC_LPT1, OnLpt1)
	ON_BN_CLICKED(IDC_FOSC0, OnFosc0)
	ON_BN_CLICKED(IDC_FOSC1, OnFosc1)
	ON_BN_CLICKED(IDC_FOSC2, OnFosc2)
	ON_BN_CLICKED(IDC_CLKR, OnClkr)
	ON_BN_CLICKED(IDC_BO25, OnBo25)
	ON_BN_CLICKED(IDC_PRHI, OnPrhi)
	ON_BN_CLICKED(IDC_RPD, OnRpd)
	ON_BN_CLICKED(IDC_WDTE, OnWdte)
	ON_BN_CLICKED(IDC_SEC1, OnSec1)
	ON_BN_CLICKED(IDC_SEC2, OnSec2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDialog message handlers

void COptionsDialog::OnLpt1() 
{
	m_nSelectedPort = 1;
}

void COptionsDialog::OnLpt2() 
{
	m_nSelectedPort = 2;
}

void COptionsDialog::OnLpt3() 
{
	m_nSelectedPort = 3;
}


BOOL COptionsDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	extern CPhilprogApp theApp;

	m_nSelectedPort = theApp.m_nCurrentPort;
	m_SelectedConfig = theApp.m_ConfigBits;
	m_SelectedSecurity = theApp.m_SecurityBits;

	switch(m_nSelectedPort)
	{
	case 1:
		m_PortButton1.SetCheck(1);
			break;
	case 2:
		m_PortButton2.SetCheck(1);
			break;
	case 3:
		m_PortButton3.SetCheck(1);
			break;
	}

	if ((m_SelectedConfig & 0x01) != 0 ) m_FOSC0.SetCheck(1);
	if ((m_SelectedConfig & 0x02) != 0 ) m_FOSC1.SetCheck(1);
	if ((m_SelectedConfig & 0x04) != 0 ) m_FOSC2.SetCheck(1);
	if ((m_SelectedConfig & 0x08) != 0 ) m_CLKR.SetCheck(1);
	if ((m_SelectedConfig & 0x10) != 0 ) m_BO25.SetCheck(1);
	if ((m_SelectedConfig & 0x20) != 0 ) m_PRHI.SetCheck(1);
	if ((m_SelectedConfig & 0x40) != 0 ) m_RPD.SetCheck(1);
	if ((m_SelectedConfig & 0x80) != 0 ) m_WDTE.SetCheck(1);
	if ((m_SelectedSecurity & 0x40) != 0) m_SEC1.SetCheck(1);
	if ((m_SelectedSecurity & 0x80) != 0) m_SEC2.SetCheck(1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COptionsDialog::OnFosc0() 
{
	if (m_FOSC0.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x01;
	}
	else
	{
		m_SelectedConfig &= 0xFE;
	}
}

void COptionsDialog::OnFosc1() 
{
	if (m_FOSC1.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x02;
	}
	else
	{
		m_SelectedConfig &= 0xFD;
	}
}

void COptionsDialog::OnFosc2() 
{
	if (m_FOSC2.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x04;
	}
	else
	{
		m_SelectedConfig &= 0xFB;
	}
}

void COptionsDialog::OnClkr() 
{
	if (m_CLKR.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x08;
	}
	else
	{
		m_SelectedConfig &= 0xF7;
	}
}

void COptionsDialog::OnBo25() 
{
	if (m_BO25.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x10;
	}
	else
	{
		m_SelectedConfig &= 0xEF;
	}
}

void COptionsDialog::OnPrhi() 
{
	if (m_PRHI.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x20;
	}
	else
	{
		m_SelectedConfig &= 0xDF;
	}
}

void COptionsDialog::OnRpd() 
{
	if (m_RPD.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x40;
	}
	else
	{
		m_SelectedConfig &= 0xBF;
	}
}

void COptionsDialog::OnWdte() 
{
	if (m_WDTE.GetCheck() == 1)
	{
		m_SelectedConfig |= 0x80;
	}
	else
	{
		m_SelectedConfig &= 0x7F;
	}
}

void COptionsDialog::OnSec1() 
{
	if (m_SEC1.GetCheck() == 1)
	{
		m_SelectedSecurity |= 0x40;
	}
	else
	{
		m_SelectedSecurity &= 0xBF;
	}
}

void COptionsDialog::OnSec2() 
{
	if (m_SEC2.GetCheck() == 1)
	{
		m_SelectedSecurity |= 0x80;
	}
	else
	{
		m_SelectedSecurity &= 0x7F;
	}
}
