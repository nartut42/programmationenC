// philprogDoc.h : interface of the CPhilprogDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHILPROGDOC_H__2DAD40CA_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_)
#define AFX_PHILPROGDOC_H__2DAD40CA_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "buffer.h"

class CPhilprogDoc : public CDocument
{
protected: // create from serialization only
	CPhilprogDoc();
	DECLARE_DYNCREATE(CPhilprogDoc)

// Attributes
public:
	CBuffer Buffer1;
 
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhilprogDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPhilprogDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPhilprogDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHILPROGDOC_H__2DAD40CA_2DD5_11D4_97BC_44C1FCC00000__INCLUDED_)
