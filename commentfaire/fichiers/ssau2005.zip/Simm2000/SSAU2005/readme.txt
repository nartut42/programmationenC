Project SSAU2005 contains the following files:

blckdiag.gif		Block diagram
Chip.jpg		Picture of P87LPC764 chip
Progrmr.jpg		Picture of programmer
abstract.doc		Project abstract
Philprog (directory)	Source code for philprog.exe
Philprog.exe		Programmer application
ssau2005.pdf		Main project documentation
circuitp.pdf		Programmer circuit diagram
circuits.pdf		Simm LPC51 circuit diagram