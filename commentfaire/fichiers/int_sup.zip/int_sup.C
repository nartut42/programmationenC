
#include	<pic.h>

#define INIT_PORTA      TRISA = 0x3F;       //T0CKI = entrees

static bit Int_ext; 
//*************************************************************
void main(void)
{
	init_pic();
	T0IF=0;
	GIE=1;   // valide interruption
	do
	{     
	  if(Int_ext) Int_ext=0;

	}while(!0);	
}	

//*************************************************************
void interrupt traite_int(void)
{
	
        if(T0IF)
        {
	      Int_ext=1; 
		TMR0=0xFF;
	      T0IF=0;
        }        
}
//*************************************************************
void init_pic(void)
{     
      INIT_PORTA;	
      T0CS=1;  // Entree d'horloge sur T0CKI (RA4)
      T0SE=1;  // front descendant
      T0IE=1;  // valide interruption Timer0 
      TMR0=0xFF; // initialise le compteur FFh
}
