/**********************************************************************
 *    RS_PIC
 *    Simulation d'un UART 2400,N,8,1
 *    Auteur: Claude Dreschel
 *    Claude Dreschel <Claudedel@wanadoo.fr>
 **********************************************************************/
#include	<pic1684.h>


#define	XTAL	        4000000	        //  4.000 MHz
#define	PORTBIT(adr, bit)	((unsigned)(&adr)*8+(bit))
#define 	ON      1
#define 	OFF     0 
/*	Baud rate	*/
#define	BRATE	2400		//2400 bauds
/*	Parametres  */

#define	DLY			3		// 3 cycles de boucle attente
#define	RX_TEMPO		25		// Fixe le temps de scrutation d'un bit(9600=>15)
#define	TX_TEMPO		24		// Fixe la duree d'un bit (9600=>14)
#define	DELAY(tempo)	(((XTAL/4/BRATE)-(tempo))/DLY)
/*     Variables                           */
static bit RxData    @  PORTBIT(PORTB,0);    // Rxd > RB0
static bit TxData    @  PORTBIT(PORTB,3);    // Txd > RB3
static bit receive,transmit;

/************************************************************/	
unsigned char getch(void);
void putch(unsigned char valeur);
void put_string(const unsigned char * s);
void init_pic(void);
/************************************************************
	Programme principal
	- initialisation du pic 
      - en boucle, lecture d'un caractere et �mission sur Txd.
************************************************************/
		
void main(void)
{
unsigned char car;

	init_pic();
	
   put_string("TEST DE LA LIAISON SERIE DE MON PIC");
	
   do
   {   
      car=getch();
	putch(car);
     
   }while(!0);		// le programme continue
}    

/*******************************************************************
*     fonction getch(): lecture d'un caractere sur
*                       la liaison serie. A 2400 bits/S
*                       la scrutation se fait  a trois reprises
*				   !  !  !
*				|-----------| toutes les 100 �S pd la 
*				presence d'un bit et ce toutes les 400�S. 
*                       (dly) 2400,N,8,1 
********************************************************************/ 
unsigned char getch(void)
{
unsigned char nb_bit, dly,caractere;
static bit Rx1,Rx2;

      caractere=0;
      while(!RxData);  //Attente bit stop 
	for(;;) {
	while(RxData)
		continue; // Attente bit start 
		dly = DELAY(RX_TEMPO)/2;
		do;
		while(--dly);     // temporisation 1/2 start
	if(RxData)
		continue; // Bruit
            receive=ON;
		nb_bit = 8;
		caractere = 0;
            dly = DELAY(RX_TEMPO)/4;      //100�S
		do;
		while(--dly);
	if(RxData)
		continue; // Bruit 
		do {
		   
			dly = DELAY(RX_TEMPO)/2;   //200�S
			do;
			while(--dly);
			Rx1=RxData;
			dly = DELAY(RX_TEMPO)/4;   //100�S
			do;
			while(--dly);
			Rx2=RxData;
			dly = DELAY(RX_TEMPO)/4;   //100�S
			do;
			while(--dly);
		      Rx1 ^= Rx2;       
			if(Rx1)	Rx2=RxData; 
			caractere = (caractere >> 1) | (Rx2 << 7);
		

		} while(--nb_bit);
		receive=OFF;
		return (caractere);
	}
}
/*******************************************************************
          fonction putch(): lecture d'un caractere sur
                              la liaison serie. 
*******************************************************************/
void putch(unsigned char valeur)
{
unsigned char nb_bit, dly;


       transmit = ON;
       nb_bit = 9;  // 1 start+8 bits  
       TxData=0;    // bit start 
           
	do
	 {
		dly = DELAY(TX_TEMPO);	// duree d'un bit
		do;
		while(--dly);
		if(valeur & 1)
			TxData = 1;
		else
			TxData = 0;
		valeur = (valeur >> 1);
      } while(--nb_bit);
      	TxData = 1;
            dly = DELAY(TX_TEMPO);	// duree d'un bit
		do;
		while(--dly);
		receive=OFF;
}
/*******************************************************************
*	fonction put_string(): ecriture d'une chaine de caracteres
*     sur la liaison serie.
********************************************************************/
void put_string(const unsigned char * s)
{
	while(*s)
		putch(*s++);
}

/**********************************************************
	init_pic(): initialise le PIC
***********************************************************/

void init_pic(void)
{
      TRISB = 0x1;	            // bit 0 input
   
}

