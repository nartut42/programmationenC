#include	<pic1687x.h>

#define INIT_PORTA      TRISA = 0x3F;       //PortA = entrees
// Les deux '#define' suivant sont a supprimer s'ils existent dans votre <picxxx.h>
#define	EEPROM_WRITE(addr, value) while(WR)continue;EEADR=(addr);EEDATA=(value);EEPGD=0;GIE=0;WREN=1;\
				EECON2=0x55;EECON2=0xAA;WR=1;WREN=0
#define	EEPROM_READ(addr) ((EEADR=(addr)),(EEPGD=0),(RD=1),EEDATA)

//**************************************************************************
void ecriture_eeprom(unsigned char adr,unsigned int valeur);
unsigned int lecture_eeprom(unsigned char adr);
void init_pic(void);
void eeprom_write(unsigned char addr, unsigned char value);
unsigned char eeprom_read(unsigned char addr);
//************************************************************************
void main(void)
{
int alarme_tension;
	init_pic();
		
	if(lecture_eeprom(0) !=0xFFFF) // EEPROM vierge ?
	{
		
		alarme_tension = lecture_eeprom(0); // valeur valide
		
	}else
	{
		alarme_tension=120; //12V        
            ecriture_eeprom(0,alarme_tension); // donnee sauvegardee

      }	
               
	while(!0);	 // fin du programme
}	

//*****************************************************************
void eeprom_write(unsigned char addr, unsigned char value)
{
	EEPROM_WRITE(addr, value);
	GIE=1;  // si besoin	
}	
unsigned char eeprom_read(unsigned char addr)
{
    	return(EEPROM_READ(addr)); 
}	
//**************************************************************
void ecriture_eeprom(unsigned char adr,unsigned int valeur)
{
		eeprom_write(adr,(unsigned char)valeur);
		valeur >> = 8;
		eeprom_write(adr+1,(unsigned char)valeur);
}
		
unsigned int lecture_eeprom(unsigned char adr)
{
unsigned int temp;
		temp=(unsigned char)eeprom_read(adr+1);
		temp << = 8;
		temp|=(unsigned char)eeprom_read(adr);
       return(temp);
}
		
//**************************************************************
void init_pic(void)
{     
      INIT_PORTA;	
	GIE=1; // si besoin
     
}
