// Exemple d'�mission d'une chaine de caract�res et de r�ception de caract�res
// 9600,N,8,1
// Claude Dreschel 2001

#include	<pic1687x.h>

/* Frequence du quartz   */
#define XTAL    		11059200  
/*	Baud rate	*/
#define BRATE	   	9600
#define VALEURBRG    	(XTAL/16/BRATE)-1
#define  CR			0x0D
//*******************************************************************
void init_pic(void);
char getch(void);
void putch(char c);
void put_string(const unsigned char * s);
//*******************************************************************
void main(void)
{

	init_pic();
	while(getch()!=CR); // attente du caractere fin ligne
	put_string("OK RECU UN CR");
	putch('.');

	while(!0);
}
//********************************************************************
/*         fonction init_pic()
*********************************************************************/ 
void init_pic(void)
{
	
	SYNC=0;           //mode asynchrone
      SPEN=1;           //port s�rie valide
      RX9=0;            // 8 bits en r�ception
	TX9=0;		// 8 bits en emission
      CREN=1;           //valide reception continue
	TXEN=1;		// valide emission 
      BRGH=1;           //Bits/s=Fosc/(16(X+1)
      SPBRG=VALEURBRG;  //9600 bits/s (X=71)
}      
//*******************************************************************
/*          fonction getch(): lecture d'un caractere sur
                              la liaison serie.                            
********************************************************************/ 
char getch(void)
{
      while(!RCIF);
      return (RCREG);
}
//*******************************************************************
/*		fonction putch(): ecriture dun caractere sur 
					la liaison serie.
********************************************************************/
void putch(char c)
{
	while(!TXIF);
	TXREG=c;
}
//*******************************************************************
/*		fonction put_string(): ecriture d'une chaine de caracteres
						 sur la liaison serie.
********************************************************************/
void put_string(const unsigned char * s)
{
	while(*s)
		putch(*s++);
}

