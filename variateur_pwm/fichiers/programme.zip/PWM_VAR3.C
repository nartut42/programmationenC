/*********************************************************************
*   PWM_VAR VER1.3: VARIATEUR DE VITESSE POUR MOTEUR A COURANT CONTINU
*   EN FONCTION DE LA DUREE DES IMPULSIONS ISSUES D'UN RECEPTEUR DE 
*   RADIOCOMMANDE.
*       Commande d'un pont en H de MOSFET canal N et P
*       Marche avant - marche arriere - Frein moteur
*       Commande du variateur en PWM
*       
* points de fonctionnement programmable: 
* min -zone neutre min-zone neutre max - max
*       points m�moris�s en EEPROM
*
* Ces fichiers sont la propri�t� de l'auteur Claude Dreschel. Ils ne sont 
* ni des FreeWare ni des Shareware. A ce titre, ils ne peuvent �tre copi�s
* enti�rement ou en partie � des fins commerciales. 
* Copyright Claudedel@microcontroleur.fr.st
*********************************************************************/
#include <pic1687x.h>



#define INIT_PORTB      TRISB=0b00000001	//PortB Config
#define INIT_PORTC_AV   TRISC=0b00001100	//PortC Config AV 
#define INIT_PORTC_AR   TRISC=0b00001010	//PortC Config AR
#define INIT_PORTC_BKE  TRISC=0b00001110	//PortC Config Frein moteur
#define INIT_PORTA	TRISA=0b00000001	//PortA lecture tension


static bit M_AVANT   @ ((unsigned)&PORTB*8+2);	//Marche avant T4 ON
static bit M_ARRIERE @ ((unsigned)&PORTB*8+3);	//Marche arriere T3 ON
static bit PWM_AV    @ ((unsigned)&PORTC*8+1);	//PWM avant T1
static bit PWM_AR    @ ((unsigned)&PORTC*8+2);	//PWM arriere T2
static bit RX_PULSE  @ ((unsigned)&PORTC*8+3);	//PULSE du recepteur
static bit BP1	     @ ((unsigned)&PORTB*8+0);	//BOUTON POUSSOIR
static bit LED	     @ ((unsigned)&PORTB*8+1);	//LED visu Batt faible & programmation
static bit TEST	     @ ((unsigned)&PORTB*8+4);	//TEST PAS DE RECEPTION

// VALEURS PAR DEFAUT
#define NEUTRE_MIN	4000		//1.45mS
#define NEUTRE_MAX	4300		//1.55mS
#define MAX		5200		//1.88mS
#define	MIN		3200		//1.15mS
#define PARASITE_MIN    2200		//0.8ms	
#define PARASITE_MAX    6000		//2.2ms	

#define ON		0
#define OFF		1


//******************************************************************
unsigned int valeur_rc;			
unsigned int neutre_min,neutre_max,max,min;
unsigned int resultat_mesure[4];
unsigned char tempo_pulse;
unsigned char compte_pulse_neutre;
unsigned char nombre_batt_faible;
float div_haut,div_bas;
static bit avant,arriere,absence_pulse,tempo_fenetre;
static bit tension_faible,signal_batt_faible,led_batt_faible;

//*****************************************************************
void interrupt traite_int(void);
void marche_avant(void);
void marche_arriere(void);
void frein_moteur(void);
void clignote_LED(unsigned char nombre);
void delay(void);
void erreur_LED(void);
bit test_neutre(void);
void init_pic(void);
void Duty_cycle(void);
void calcul_TMR0(unsigned int valeur);
void config_pulse(void);
unsigned int mesure_pulse(void);
void traite_pulse(void);
void lecture_config_eeprom(void);
unsigned int lecture_eeprom(unsigned char adr);
static bit config_eeprom(void);
void config_defaut(void);
void calcul_facteur_div(void);
void init_PWM(void);
bit test_neutre(void);
void mesure(void);
//*****************************************************************
void interrupt traite_int(void)
{
	
        if(TMR1IF)
        {	
		if(++tempo_pulse == 20)  absence_pulse=1; // 1/2 seconde
		TMR1IF=0;
	}  
	if(TMR0IF)
	{
		tempo_fenetre  ^=  1;
		
		if(tempo_fenetre)
		{
			TMR0=169;  //8ms
		}else TMR0=126;	   //12ms	
		TMR0IF=0;
	}
	
}
//*****************************************************************


void marche_avant(void)
{
	M_ARRIERE=OFF;
	M_AVANT=OFF;
	asm("nop");
	INIT_PORTC_AV;		// MARCHE AVANT
	M_AVANT=ON;
	arriere=0;
	avant=1;
}


void marche_arriere(void)
{
	M_AVANT=OFF;
	M_ARRIERE=OFF;
	asm("nop");
	INIT_PORTC_AR;		// MARCHE ARRIERE
	M_ARRIERE=ON;
	arriere=1;
	avant=0;
}


void frein_moteur(void)
{
	valeur_rc=0;
	Duty_cycle();
	INIT_PORTC_BKE;		// FREIN MOTEUR
	asm("nop");
	asm("nop");
	M_ARRIERE=ON;
	M_AVANT=ON;
	avant=0;
	arriere=0;
	
}
//******************************************************************
void init_pic(void)
{
	INIT_PORTA;
	INIT_PORTB;
	OPTION=0b000000111; // timer0 prescaler /256
	LED=OFF;
	TMR1CS=0;	//internal clock
	TMR1H=0;
	TMR1L=0;
	TMR1IE=1;	//interrupt TMR1=ON
	TMR1IF=0;
	TMR0IF=0;
	PEIE=1;
	GIE=1;
	ADFM=1;
	ADCS1=1;
        ADON=1;	
}

//******************************************************************
void clignote_LED(unsigned char nombre)
{
unsigned char x;

	for(x=0;x!=nombre;x++)
	{
		LED=ON;
		absence_pulse=0;
		tempo_pulse=0;
		TMR1ON=1;
		while(!absence_pulse);
		TMR1ON=0;
		LED=OFF;
		absence_pulse=0;
		tempo_pulse=0;
		TMR1ON=1;
		while(!absence_pulse);
		absence_pulse=0;
		TMR1ON=0;
	}	


}

void delay(void)
{		
	absence_pulse=0;
	tempo_pulse=0;
	TMR1ON=1;
	while(!absence_pulse);
	TMR1ON=0;

}
void erreur_LED(void)
{

	T1CKPS1=1;
	clignote_LED(1);
	T1CKPS1=0;
}

//******************************************************************
void calcul_TMR0(unsigned int valeur)
{

	TMR0=256 - (unsigned int)((44200 - valeur) >> 8); //  pendant 16ms
	tempo_fenetre=0;	// ferme la fenetre

}
//******************************************************************
void config_pulse(void)
{
unsigned int resultat_precedent,resultat;
unsigned char x;
static bit erreur_config;

	x=0;
	erreur_config=0;
	compte_pulse_neutre=0;
	resultat_precedent=0;
	neutre_max=NEUTRE_MAX; //param par defaut
	neutre_min=NEUTRE_MIN; //param par defaut
	TMR1ON=0;
	frein_moteur();
	
	LED=ON;
	while(!test_neutre());  // attend manche zone neutre
	LED=OFF;
	
	do
	{
		while(!BP1);
		while(RX_PULSE);
		while(BP1 || !RX_PULSE);
		
		TMR1ON=0;
		TMR1H=0;
		TMR1L=0;
		TMR1ON=1;				
		while(RX_PULSE);	
		TMR1ON=0;				
		resultat=0;
		resultat=TMR1H;
		resultat <<=8;
		resultat |= TMR1L; 
		while(!BP1);
	if ((resultat < PARASITE_MIN) || (resultat > PARASITE_MAX))
	{
		erreur_config=1;
		
	}else 	
	{
		if(resultat <= resultat_precedent)
		{
			erreur_LED();
			erreur_config=1;
		
		}else
		{
			resultat_precedent=resultat;
			resultat_mesure[x]=resultat;
			clignote_LED(x+1);
		
		}	
	}
		x++;

	}while((x!=4) && (!erreur_config));
	

	if(!erreur_config)
	{	
		
		for(x=0;x!=4;x++)
		{	
			resultat=resultat_mesure[x];
			eeprom_write((2*x),(unsigned char) resultat);
			resultat >> = 8;
			eeprom_write(((2*x)+1),(unsigned char) resultat);
						
		}	
	}
	
}
//******************************************************************


unsigned int lecture_eeprom(unsigned char adr)
{
unsigned int lecture;
	lecture=0;
	lecture=eeprom_read(adr+1);
	lecture << = 8;
	lecture|= eeprom_read(adr);	
	return(lecture);
}		
		
void lecture_config_eeprom(void)
{
unsigned int valeur;

	
	valeur=lecture_eeprom(0);
	min=valeur;
	valeur=lecture_eeprom(2);
	neutre_min=valeur;
	valeur=lecture_eeprom(4);
	neutre_max=valeur;
	valeur=lecture_eeprom(6);
	max=valeur;
			
}


static bit config_eeprom(void)
{
	if(lecture_eeprom(0) != 0xFFFF) return(1);
	else return(0);

}


void config_defaut(void)
{
	min=MIN;
	neutre_min=NEUTRE_MIN;
	neutre_max=NEUTRE_MAX;
	max=MAX;
}

//******************************************************************
void Duty_cycle(void)
{
unsigned int temp;
	temp=valeur_rc;
	valeur_rc >>=2;
	CCPR1L=(unsigned char)valeur_rc;
	CCPR2L=(unsigned char)valeur_rc;
	temp &=3;			// temp AND 3
	temp <<=4;			
	CCP1CON |=(unsigned int)temp;   // CCP1CON.4 -5 = temp.4-5
	CCP2CON |=(unsigned int)temp;

}

bit test_neutre(void)
{
unsigned int resultat;
	
		
	TMR1ON=0;
	TMR1H=0;
	TMR1L=0;
	while(RX_PULSE);
	while(!RX_PULSE);
	TMR1ON=1;				// Timer1 on
	while(RX_PULSE);	
	TMR1ON=0;				//Timer1 Off
	resultat=0;
	resultat=TMR1H;
	resultat <<=8;
	resultat |= TMR1L; 
	  	
	if((resultat < neutre_max) && (resultat > neutre_min))
	{
		compte_pulse_neutre++;
		calcul_TMR0(resultat);
		absence_pulse=0;	//compteur 1/2S = 0 
		tempo_pulse=0;		//compteur 1/2S = 0 

	}else
	{
			
		compte_pulse_neutre=0;

	}
	if(compte_pulse_neutre==20) return(1);
	else return(0);
}


unsigned int mesure_pulse(void)
{
unsigned int resultat;
	
	TMR1ON=0;
	TMR1H=0;
	TMR1L=0;
	TMR1ON=1;		// Timer1 on
		while(RX_PULSE && tempo_fenetre);
	TMR1ON=0;		//Timer1 Off
	resultat=0;
	resultat=TMR1H;
	resultat <<=8;
	resultat |= TMR1L; 
	if(tempo_fenetre) return(resultat);
	else return(0);


}


void traite_pulse(void)
{
unsigned int resultat;
float valeur;
static bit erreur_pulse;
unsigned char compte_erreur;
		
	erreur_pulse=0;
	resultat=mesure_pulse();
	TMR1ON=1;
	if ((resultat < PARASITE_MIN) || (resultat > PARASITE_MAX)) erreur_pulse=1;
  	
  	if(!erreur_pulse)
  	{
  		
  		
  		
		if(resultat > neutre_max)
		{
			if(resultat < max)
			{
  				resultat -=neutre_max;	
  				valeur= (resultat/div_haut);
  				valeur_rc=(unsigned int)valeur;
 	  			}else valeur_rc=255;	
  	    			if(arriere) frein_moteur(); 
  	    			marche_avant();
  	  		
		  	
	  		}else if(resultat < neutre_min)
	  		{
	  			if(resultat > min)
	  			{
  					resultat = (neutre_min-resultat);
  					valeur= (resultat/div_bas);
  					valeur_rc=(unsigned int)valeur;
  				}else valeur_rc=255;
  				if(avant) frein_moteur();
  				marche_arriere();
  					  	
  			}else         //alors dans zone neutre
  			{
  				frein_moteur();
  				if(tension_faible) signal_batt_faible=1;	  			
  			}

		calcul_TMR0(resultat);
			
  		compte_erreur=0;	//pas d'erreur duree pulse=ok
		absence_pulse=0;	// compteur 1S =0
		tempo_pulse=0;
	  			
	  			
  	}else
  	{
  		if(compte_erreur++ == 25);  // nombre erreur pulse
		{
  			frein_moteur();
			absence_pulse=1;	//si 25 erreurs attend pulse neutre
		}

  	}
	  	
	  	
  	if(tension_faible)
  	{
		
  		if(!signal_batt_faible)
  		{
  			valeur_rc=127;	// 1/2 puissance
				
  		}
			
  	}
  	Duty_cycle();		//actualise compteur PWM
		
}

//******************************************************************

void init_PWM(void)
{
	PR2=63;			//PWM=43.200KHz periode=2,3148e-5S
	CCPR1L=0;		//Duty cycle =0
	CCPR2L=0;		//Duty cycle =0
	CCP1CON= 0b00001100;    //PWM1 mode Duty cycle =0
	CCP2CON= 0b00001100;	//PWM2 mode Duty cycle =0
	TMR2ON=1;		// Timer2 =On
	

}
void calcul_fact_div(void)
{
	div_haut=(max-neutre_max)/255;
	div_bas=(neutre_min-min)/255;
		
}	
//******************************************************************

void mesure(void)
{
unsigned int valeur;

      
	valeur=0;
	ADIF=0;
	ADGO=1;
	while(!ADIF);
	valeur = ADRESL;
	valeur +=(ADRESH << 8);
	if (valeur < 292)   //292 pour 1.425V  
	{
      		if(nombre_batt_faible++ == 50) tension_faible=1; // compte le nombre mesure batt faible successive
		led_batt_faible=1;
      	 
      	}	 
      	else 
      	{
		led_batt_faible=0;
		nombre_batt_faible=0;
      	}	
      	if (led_batt_faible) LED=0;
	else LED=1; 
      
}

//******************************************************************
void main(void)
{



	init_pic();
	frein_moteur();
	init_PWM();
	ADCON0 = (0 << 3)+ 129;
	tempo_fenetre=1;
	if(!BP1) config_pulse();
	delay();
	if(config_eeprom()) lecture_config_eeprom(); 
	else config_defaut();

	calcul_fact_div();
	tension_faible=0;
	signal_batt_faible=0;
	led_batt_faible=0;
	absence_pulse=0;
	tempo_pulse=0;
	compte_pulse_neutre=0;
	while(RX_PULSE);	
	while(!test_neutre());  // attend manche zone neutre
	TEST=0;
	TMR0IE=1; 
	TMR1ON=1;  
	do
	{
	   
	  
	  if(absence_pulse)
	  {
		TEST=1;
	  	TMR1ON=0;
	  	frein_moteur();
		TMR1L=0;
		TMR1H=0;
	  	absence_pulse=0;
	  	tempo_pulse=0;
	  	compte_pulse_neutre=0;
	  	while(!test_neutre());  // attend manche zone neutre
		TMR1ON=1; 
		TEST=0; 
	  }
	  
	  	
		while(!tempo_fenetre);

		if(RX_PULSE) while(tempo_fenetre);

		else
		{
			
			while(!RX_PULSE && tempo_fenetre);

			if(RX_PULSE) traite_pulse();

		}
		
	   	
	mesure();
	
	  
	  
	  
	  
	}while(!0); 		

}
//******************************************************************
//			FIN
//******************************************************************
